export const whatsappAdmin = process.env.NEXT_PUBLIC_WHATSAPP_ADMIN || "254700520520";

export type PaymentProvider = "mpesa" | "stripe" | "paypal" | "flutterwave";

export function createWhatsAppAdminUrl(message: string) {
  return `https://wa.me/${whatsappAdmin}?text=${encodeURIComponent(message)}`;
}

export function looksLikeSpam(message: string) {
  const lower = message.toLowerCase();
  const linkCount = lower.match(/https?:\/\//g)?.length || 0;
  const blocked = ["crypto profit", "free money", "click now"];
  return linkCount > 1 || blocked.some((term) => lower.includes(term));
}

export const paymentProviderLabels: Record<PaymentProvider, string> = {
  mpesa: "M-PESA",
  stripe: "Visa/Mastercard",
  paypal: "PayPal",
  flutterwave: "Flutterwave"
};

export function requireEnv(name: string) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing environment variable: ${name}`);
  }
  return value;
}
