import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "520 School | Future of African Storytelling",
  description:
    "A cinematic African media-tech ecosystem for film education, streaming, creator funding, talent discovery, jobs, events, archives, and community-powered storytelling.",
  openGraph: {
    title: "520 School",
    description: "Enter the future of Kenyan and African storytelling.",
    images: ["/images/hero-nairobi-afterlight.jpg"]
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
