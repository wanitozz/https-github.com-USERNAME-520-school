import { NextResponse } from "next/server";
import { createWhatsAppAdminUrl, looksLikeSpam } from "../../../lib/platform";

export async function POST(request: Request) {
  const payload = await request.json();
  const message = String(payload.message || "");

  if (!message.trim()) {
    return NextResponse.json({ ok: false, error: "Message is required" }, { status: 400 });
  }

  const spam = looksLikeSpam(message);
  const reviewStatus = spam ? "held_for_spam_review" : "pending_admin_approval";

  return NextResponse.json({
    ok: true,
    reviewStatus,
    whatsappForwardUrl: createWhatsAppAdminUrl(
      `520 School moderation\nName: ${payload.name || "Anonymous"}\nCategory: ${payload.category || "Comment"}\nMessage: ${message}`
    )
  });
}
