import { NextResponse } from "next/server";
import { paymentProviderLabels, type PaymentProvider } from "../../../lib/platform";

const supportedProviders: PaymentProvider[] = ["mpesa", "stripe", "paypal", "flutterwave"];

export async function POST(request: Request) {
  const payload = await request.json();
  const provider = String(payload.provider || "").toLowerCase() as PaymentProvider;

  if (!supportedProviders.includes(provider)) {
    return NextResponse.json({ ok: false, error: "Unsupported payment provider" }, { status: 400 });
  }

  return NextResponse.json({
    ok: true,
    provider,
    label: paymentProviderLabels[provider],
    mode: "scaffold",
    nextStep:
      provider === "mpesa"
        ? "Create Daraja STK Push request"
        : provider === "stripe"
          ? "Create Stripe Checkout session"
          : provider === "paypal"
            ? "Create PayPal order"
            : "Create Flutterwave payment link"
  });
}
