import { NextResponse } from "next/server";
import { createWhatsAppAdminUrl } from "../../../lib/platform";

export async function POST(request: Request) {
  const payload = await request.json();
  const category = String(payload.category || "General submission");
  const name = String(payload.name || "Unnamed creator");

  return NextResponse.json({
    ok: true,
    status: "received",
    category,
    uploadTarget: "cloudinary_unsigned_upload_or_signed_server_upload",
    adminNotificationUrl: createWhatsAppAdminUrl(
      `520 School submission\nName: ${name}\nCategory: ${category}\nPortfolio: ${payload.portfolioUrl || "Not provided"}`
    )
  });
}
