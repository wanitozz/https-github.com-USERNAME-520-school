export default function Home() {
  return (
    <main className="prototype-shell">
      <iframe
        className="prototype-frame"
        src="/prototype/index.html"
        title="520 School cinematic platform prototype"
      />
    </main>
  );
}
