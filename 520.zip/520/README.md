# 520 School

An ultra-modern cinematic prototype for an African media-tech ecosystem: film school, streaming platform, creator community, crowdfunding system, talent hub, archive, merch store, events, jobs, and admin dashboard.

## Preview

This workspace includes an offline static preview so the experience can run even before dependencies are installed:

```bash
node tools/serve-static.mjs
```

Then open `http://localhost:4173`.

## Production Stack

The project is scaffolded for the requested stack:

- Next.js and React
- TailwindCSS
- Framer Motion, GSAP, Three.js
- Firebase Authentication
- PostgreSQL
- Cloudinary
- Stripe, M-PESA, PayPal, Flutterwave

After a package manager is available:

```bash
npm install
npm run dev
```

## Integration Notes

- Replace the demo WhatsApp number in `.env.example`.
- Add production payment credentials before enabling checkout.
- Connect moderation, comments, submissions, inventory, memberships, streaming metadata, and admin analytics to a database.
- Move uploaded media to Cloudinary or a comparable adaptive delivery layer.
- Keep the generated PNG stills as fallbacks for fast loading on slower connections.
