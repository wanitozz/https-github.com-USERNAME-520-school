const fs = require("fs");
const path = require("path");
const { PNG } = require("pngjs");
const jpeg = require("jpeg-js");

const outDir = path.join(__dirname, "..", "public", "images");
fs.mkdirSync(outDir, { recursive: true });

const clamp = (value) => Math.max(0, Math.min(255, value));
const mix = (a, b, t) => a + (b - a) * t;
const hex = (value) => {
  const clean = value.replace("#", "");
  return [
    parseInt(clean.slice(0, 2), 16),
    parseInt(clean.slice(2, 4), 16),
    parseInt(clean.slice(4, 6), 16),
  ];
};

function drawCircle(png, cx, cy, r, color, alpha = 1) {
  const [cr, cg, cb] = color;
  const minX = Math.max(0, Math.floor(cx - r));
  const maxX = Math.min(png.width - 1, Math.ceil(cx + r));
  const minY = Math.max(0, Math.floor(cy - r));
  const maxY = Math.min(png.height - 1, Math.ceil(cy + r));

  for (let y = minY; y <= maxY; y += 1) {
    for (let x = minX; x <= maxX; x += 1) {
      const dx = x - cx;
      const dy = y - cy;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d <= r) {
        const feather = Math.max(0, 1 - d / r);
        const a = alpha * Math.min(1, feather * 1.7);
        const i = (png.width * y + x) << 2;
        png.data[i] = clamp(mix(png.data[i], cr, a));
        png.data[i + 1] = clamp(mix(png.data[i + 1], cg, a));
        png.data[i + 2] = clamp(mix(png.data[i + 2], cb, a));
      }
    }
  }
}

function drawRect(png, x, y, w, h, color, alpha = 1) {
  const [cr, cg, cb] = color;
  const minX = Math.max(0, Math.floor(x));
  const maxX = Math.min(png.width - 1, Math.ceil(x + w));
  const minY = Math.max(0, Math.floor(y));
  const maxY = Math.min(png.height - 1, Math.ceil(y + h));

  for (let py = minY; py <= maxY; py += 1) {
    for (let px = minX; px <= maxX; px += 1) {
      const i = (png.width * py + px) << 2;
      png.data[i] = clamp(mix(png.data[i], cr, alpha));
      png.data[i + 1] = clamp(mix(png.data[i + 1], cg, alpha));
      png.data[i + 2] = clamp(mix(png.data[i + 2], cb, alpha));
    }
  }
}

function drawLine(png, x1, y1, x2, y2, color, alpha = 1, width = 2) {
  const steps = Math.ceil(Math.hypot(x2 - x1, y2 - y1));
  for (let s = 0; s <= steps; s += 1) {
    const t = s / steps;
    drawCircle(png, mix(x1, x2, t), mix(y1, y2, t), width, color, alpha);
  }
}

function makeFrame(file, opts) {
  const width = opts.width || 1600;
  const height = opts.height || 960;
  const png = new PNG({ width, height });
  const top = hex(opts.top);
  const middle = hex(opts.middle);
  const bottom = hex(opts.bottom);
  const accent = hex(opts.accent);
  const second = hex(opts.second);
  const shadow = hex("#050509");

  for (let y = 0; y < height; y += 1) {
    const v = y / (height - 1);
    const split = v < 0.55 ? v / 0.55 : (v - 0.55) / 0.45;
    const from = v < 0.55 ? top : middle;
    const to = v < 0.55 ? middle : bottom;
    for (let x = 0; x < width; x += 1) {
      const u = x / (width - 1);
      const dx = u - opts.lightX;
      const dy = v - opts.lightY;
      const glow = Math.max(0, 1 - Math.sqrt(dx * dx + dy * dy) * 1.55);
      const vignette = Math.max(0, Math.sqrt((u - 0.5) ** 2 + (v - 0.5) ** 2) - 0.3) * 1.35;
      const wave = Math.sin((u * opts.waveX + v * opts.waveY) * Math.PI) * 0.06;
      const noise = ((x * 13 + y * 17 + ((x * y) % 97)) % 31) - 15;
      const i = (width * y + x) << 2;
      png.data[i] = clamp(mix(from[0], to[0], split + wave) + accent[0] * glow * 0.22 - vignette * 60 + noise * 0.36);
      png.data[i + 1] = clamp(mix(from[1], to[1], split + wave) + accent[1] * glow * 0.22 - vignette * 58 + noise * 0.28);
      png.data[i + 2] = clamp(mix(from[2], to[2], split + wave) + accent[2] * glow * 0.22 - vignette * 52 + noise * 0.22);
      png.data[i + 3] = 255;
    }
  }

  drawCircle(png, width * opts.lightX, height * opts.lightY, width * 0.24, accent, 0.35);
  drawCircle(png, width * (1 - opts.lightX * 0.38), height * (0.18 + opts.lightY * 0.24), width * 0.17, second, 0.16);

  const horizon = height * opts.horizon;
  drawRect(png, 0, horizon, width, height - horizon, shadow, 0.38);

  if (opts.scene === "city") {
    for (let n = 0; n < 34; n += 1) {
      const bw = width * (0.018 + ((n * 11) % 8) / 420);
      const bh = height * (0.1 + ((n * 17) % 20) / 120);
      const bx = width * ((n * 37) % 100) / 100;
      const by = horizon - bh + height * 0.05 * Math.sin(n);
      drawRect(png, bx, by, bw, bh, shadow, 0.82);
      if (n % 3 === 0) {
        drawRect(png, bx + bw * 0.38, by + bh * 0.12, bw * 0.14, bh * 0.65, accent, 0.28);
      }
    }
    drawLine(png, width * 0.02, horizon + height * 0.1, width * 0.98, horizon + height * 0.02, second, 0.45, 2);
    drawLine(png, width * 0.05, horizon + height * 0.22, width * 0.95, horizon + height * 0.08, accent, 0.35, 3);
  }

  if (opts.scene === "savannah") {
    drawCircle(png, width * 0.76, height * 0.2, height * 0.12, accent, 0.54);
    for (let n = 0; n < 12; n += 1) {
      const base = width * ((n * 73) % 100) / 100;
      drawLine(png, base, horizon + height * 0.05, base + width * 0.018, horizon - height * (0.08 + (n % 4) * 0.018), shadow, 0.8, 3);
      drawLine(png, base + width * 0.018, horizon - height * 0.08, base + width * 0.06, horizon - height * 0.12, shadow, 0.7, 2);
      drawLine(png, base + width * 0.018, horizon - height * 0.07, base - width * 0.045, horizon - height * 0.11, shadow, 0.65, 2);
    }
  }

  if (opts.scene === "studio") {
    drawLine(png, width * 0.12, height * 0.17, width * 0.88, height * 0.82, second, 0.2, 7);
    drawLine(png, width * 0.88, height * 0.16, width * 0.18, height * 0.84, accent, 0.18, 5);
    for (let n = 0; n < 9; n += 1) {
      const cx = width * (0.18 + n * 0.08);
      drawCircle(png, cx, height * (0.62 + Math.sin(n) * 0.03), width * 0.018, shadow, 0.86);
      drawRect(png, cx - width * 0.013, height * 0.64, width * 0.026, height * 0.15, shadow, 0.8);
    }
  }

  if (opts.scene === "portrait") {
    drawCircle(png, width * 0.52, height * 0.32, width * 0.095, shadow, 0.86);
    drawRect(png, width * 0.44, height * 0.41, width * 0.17, height * 0.34, shadow, 0.82);
    drawLine(png, width * 0.29, height * 0.78, width * 0.7, height * 0.78, accent, 0.35, 5);
    drawLine(png, width * 0.43, height * 0.53, width * 0.25, height * 0.65, shadow, 0.8, 6);
    drawLine(png, width * 0.61, height * 0.53, width * 0.78, height * 0.65, shadow, 0.8, 6);
  }

  if (opts.scene === "archive") {
    for (let n = 0; n < 18; n += 1) {
      const bx = width * (0.05 + ((n * 29) % 85) / 100);
      const by = height * (0.18 + ((n * 47) % 50) / 100);
      drawRect(png, bx, by, width * 0.12, height * 0.085, n % 2 ? second : accent, 0.12);
      drawRect(png, bx + width * 0.012, by + height * 0.012, width * 0.096, height * 0.061, shadow, 0.42);
    }
    drawLine(png, width * 0.12, height * 0.72, width * 0.88, height * 0.34, accent, 0.24, 4);
  }

  if (opts.scene === "product") {
    drawRect(png, width * 0.34, height * 0.19, width * 0.32, height * 0.5, shadow, 0.76);
    drawCircle(png, width * 0.5, height * 0.2, width * 0.05, shadow, 0.82);
    drawRect(png, width * 0.39, height * 0.26, width * 0.22, height * 0.07, accent, 0.3);
    drawLine(png, width * 0.35, height * 0.38, width * 0.2, height * 0.58, shadow, 0.74, 10);
    drawLine(png, width * 0.65, height * 0.38, width * 0.8, height * 0.58, shadow, 0.74, 10);
    drawLine(png, width * 0.38, height * 0.77, width * 0.62, height * 0.77, second, 0.35, 5);
  }

  for (let y = 0; y < height; y += 6) {
    drawRect(png, 0, y, width, 1, shadow, 0.04);
  }

  const buffer = jpeg.encode({ data: png.data, width, height }, 74).data;
  fs.writeFileSync(path.join(outDir, file), buffer);
}

const frames = [
  ["hero-nairobi-afterlight.jpg", { top: "#090b14", middle: "#291119", bottom: "#070709", accent: "#ffb04a", second: "#15c6a3", lightX: 0.68, lightY: 0.2, horizon: 0.61, waveX: 3.1, waveY: 1.2, scene: "city" }],
  ["frame-mombasa-dreams.jpg", { top: "#07121b", middle: "#163a3e", bottom: "#090808", accent: "#f26f3d", second: "#2bd5c4", lightX: 0.78, lightY: 0.24, horizon: 0.57, waveX: 2.2, waveY: 3.2, scene: "city" }],
  ["frame-savannah-signal.jpg", { top: "#150b12", middle: "#642817", bottom: "#0d0a07", accent: "#ffbf5f", second: "#58d082", lightX: 0.72, lightY: 0.23, horizon: 0.62, waveX: 1.4, waveY: 2.8, scene: "savannah" }],
  ["frame-studio-520.jpg", { top: "#05070c", middle: "#211538", bottom: "#070708", accent: "#d76dff", second: "#f5a742", lightX: 0.32, lightY: 0.25, horizon: 0.72, waveX: 4.6, waveY: 1.6, scene: "studio" }],
  ["frame-director.jpg", { top: "#09100e", middle: "#3d2418", bottom: "#070707", accent: "#f58a3d", second: "#17a589", lightX: 0.37, lightY: 0.18, horizon: 0.68, waveX: 2.8, waveY: 2.3, scene: "portrait" }],
  ["frame-archive.jpg", { top: "#090b12", middle: "#1d2930", bottom: "#080808", accent: "#e0b760", second: "#e64f44", lightX: 0.56, lightY: 0.22, horizon: 0.64, waveX: 2.4, waveY: 3.5, scene: "archive" }],
  ["frame-ai-lab.jpg", { top: "#040812", middle: "#102f42", bottom: "#08080b", accent: "#3be2ff", second: "#ff7c55", lightX: 0.48, lightY: 0.2, horizon: 0.67, waveX: 5.2, waveY: 1.5, scene: "studio" }],
  ["frame-festival.jpg", { top: "#0c0711", middle: "#3a162c", bottom: "#090608", accent: "#ffce64", second: "#e75da8", lightX: 0.62, lightY: 0.26, horizon: 0.59, waveX: 3.5, waveY: 2.6, scene: "city" }],
  ["frame-community.jpg", { top: "#06100e", middle: "#152c23", bottom: "#070807", accent: "#38d681", second: "#f06a3f", lightX: 0.28, lightY: 0.24, horizon: 0.64, waveX: 2.6, waveY: 2.2, scene: "portrait" }],
  ["merch-hoodie.jpg", { top: "#09090c", middle: "#242328", bottom: "#090807", accent: "#f29f3d", second: "#e34d3f", lightX: 0.45, lightY: 0.18, horizon: 0.72, waveX: 2.5, waveY: 2.2, scene: "product" }],
  ["merch-cap.jpg", { top: "#051011", middle: "#18332d", bottom: "#070808", accent: "#2bd5a5", second: "#f6b24d", lightX: 0.55, lightY: 0.22, horizon: 0.72, waveX: 3.4, waveY: 1.6, scene: "product" }],
  ["merch-poster.jpg", { top: "#10070b", middle: "#401018", bottom: "#080606", accent: "#e64f44", second: "#f1c56b", lightX: 0.64, lightY: 0.19, horizon: 0.72, waveX: 1.8, waveY: 3.1, scene: "product" }],
];

frames.forEach(([file, opts]) => makeFrame(file, opts));
console.log(`Generated ${frames.length} cinematic assets in ${outDir}`);
