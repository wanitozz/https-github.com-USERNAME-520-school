const fs = require("fs");
const path = require("path");
const { PDFDocument, StandardFonts, rgb } = require("pdf-lib");

async function main() {
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const ember = rgb(0.95, 0.48, 0.18);
  const text = rgb(0.1, 0.09, 0.08);

  page.drawRectangle({ x: 0, y: 0, width: 612, height: 792, color: rgb(0.98, 0.95, 0.89) });
  page.drawRectangle({ x: 42, y: 640, width: 528, height: 94, color: rgb(0.05, 0.05, 0.06) });
  page.drawText("520 SCHOOL", { x: 64, y: 690, size: 34, font: bold, color: rgb(1, 1, 1) });
  page.drawText("Future of African storytelling", { x: 66, y: 666, size: 13, font: regular, color: ember });

  const lines = [
    "520 School is a cinematic African media-tech ecosystem combining film education,",
    "streaming, production, crowdfunding, talent discovery, merchandise, jobs, events,",
    "archive work, AI creator tools, and community-powered impact.",
    "",
    "Core systems:",
    "Film academy, streaming platform, production company, creative community, public",
    "funding dashboard, talent hub, screenplay marketplace, jobs board, equipment rental,",
    "festival, documentary research hub, AI lab, live events, impact reporting, and admin.",
    "",
    "Partnership opportunities:",
    "Scholarship sponsorship, original film slates, branded documentaries, creator grants,",
    "festival stages, county labs, archive preservation, merchandise collaborations,",
    "livestream sponsorship, and investor packages.",
    "",
    "Contact: hello@520school.africa"
  ];

  let y = 586;
  for (const line of lines) {
    if (!line) {
      y -= 16;
      continue;
    }
    const isHeading = line.endsWith(":");
    page.drawText(line, {
      x: 64,
      y,
      size: isHeading ? 15 : 11,
      font: isHeading ? bold : regular,
      color: isHeading ? ember : text
    });
    y -= isHeading ? 24 : 17;
  }

  const output = await pdf.save();
  fs.writeFileSync(path.join(__dirname, "..", "public", "520-school-company-profile.pdf"), output);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
