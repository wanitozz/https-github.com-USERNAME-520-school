import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./index.html", "./script.js"],
  theme: {
    extend: {
      colors: {
        night: "#050507",
        ember: "#f29f3d",
        clay: "#e6503f",
        jade: "#2bd5a5",
        ink: "#0b0c12"
      },
      fontFamily: {
        display: ["var(--font-display)", "Inter", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        cinema: "0 30px 120px rgba(0,0,0,.55)"
      }
    }
  },
  plugins: []
};

export default config;
