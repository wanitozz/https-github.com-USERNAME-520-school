create extension if not exists "uuid-ossp";

create table users (
  id uuid primary key default uuid_generate_v4(),
  firebase_uid text unique,
  display_name text not null,
  email text unique,
  phone text,
  role text not null default 'member',
  county text,
  created_at timestamptz not null default now()
);

create table films (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  title text not null,
  format text not null,
  synopsis text not null,
  intended_budget_kes integer not null default 0,
  funding_total_kes integer not null default 0,
  production_stage text not null default 'concept',
  poster_url text,
  created_at timestamptz not null default now()
);

create table courses (
  id uuid primary key default uuid_generate_v4(),
  category text not null,
  title text not null,
  description text not null,
  duration text not null,
  difficulty text not null,
  price_kes integer not null,
  locations text[] not null default '{}',
  online_available boolean not null default true,
  instructor_name text,
  certification_details text,
  curriculum_url text
);

create table memberships (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id) on delete cascade,
  plan text not null,
  provider text not null,
  status text not null,
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

create table funding_contributions (
  id uuid primary key default uuid_generate_v4(),
  film_id uuid references films(id) on delete cascade,
  user_id uuid references users(id),
  amount_kes integer not null,
  provider text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table comments (
  id uuid primary key default uuid_generate_v4(),
  name text,
  occupation text,
  category text not null,
  message text not null,
  status text not null default 'pending',
  moderation_notes text,
  created_at timestamptz not null default now()
);

create table talent_profiles (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id),
  craft text not null,
  bio text,
  county text,
  portfolio_url text,
  reel_url text,
  votes integer not null default 0,
  featured_until timestamptz
);

create table products (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  sku text unique not null,
  price_kes integer not null,
  inventory integer not null default 0,
  image_url text,
  active boolean not null default true
);

create table jobs (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  category text not null,
  location text not null,
  compensation text,
  description text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table equipment (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  category text not null,
  daily_rate_kes integer not null,
  pickup_locations text[] not null default '{}',
  available boolean not null default true,
  policy text
);

create table events (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  category text not null,
  starts_at timestamptz not null,
  venue text,
  livestream_url text,
  ticket_price_kes integer default 0
);
